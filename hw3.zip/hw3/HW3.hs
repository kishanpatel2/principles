--1
import Data.List
newtype Poly = Poly [Double] deriving (Show, Eq)
coeffs :: [Double] -> Poly
coeffs [x] = if x == 0 then Poly[0] else Poly[0]
coeffs [x,y] = if y == 0 then Poly [x] else Poly [x,y]
coeffs [x,y,z] = if z == 0 then Poly [x,y] else Poly [x,y,z]
coeffs [x,y,z,a] = if a == 0 then Poly[x,y,z] else Poly[x,y,z,a]
coeffs [x,y,z,a,b] = if b == 0 then Poly[x,y,z,a] else Poly[x,y,z,a,b]
coeffs [x,y,z,a,b,c] = if c == 0 then Poly[x,y,z,a,b] else Poly[x,y,z,a,b,c]
coeffs [x,y,z,a,b,c,d] = if d == 0 then Poly[x,y,z,a,b,c] else Poly[x,y,z,a,b,c,d]
coeffs [x,y,z,a,b,c,d,e] = if e == 0 then Poly[x,y,z,a,b,c,d] else Poly[x,y,z,a,b,c,d,e]
coeffs [x,y,z,a,b,c,d,e,f] = if f == 0 then Poly[x,y,z,a,b,c,d,e] else Poly[x,y,z,a,b,c,d,e,f]

--2 
newtype Poly = Poly [Double] deriving (Show, Eq)
at :: Poly -> Double -> Double
Poly [x,y,z] `at` b = x + y*(b^1) + z*(b^2)
Poly [x,y,z,a] `at` b = x + y*(b^1) + z*(b^2) + a*(b^3)
Poly [x,y,z,a,c] `at` b = x + y*(b^1) + z*(b^2) + a*(b^3) + c*(b^4)
Poly [x,y,z,a,c,d] `at` b = x + y*(b^1) + z*(b^2) + a*(b^3) + c*(b^4) + d*(b^5)
Poly [x,y,z,a,c,d,e] `at` b = x + y*(b^1) + z*(b^2) + a*(b^3)+ c*(b^4) + d*(b^5) + e*(b^6)
x = if x == 0 then 0 else 1
y = if y == 0 then 0 else y
z = if z == 0 then 0 else z
a = if a == 0 then 0 else a
c = if c == 0 then 0 else c
d = if d == 0 then 0 else d
e = if e == 0 then 0 else e

--3
newtype Poly = Poly [Double] deriving (Show, Eq)
add:: Poly -> Poly -> Poly
add (Poly[x])(Poly[a]) = Poly[x+a]
add (Poly[x,y])(Poly[a,b]) = Poly[x+a,y+b] if x+a == 0 then 0 else Poly
add (Poly[x,y,z])(Poly[a,b,c]) = Poly [x+a,y+b,z+c]
add (Poly[x,y,z,x1])(Poly[a,b,c,d]) = Poly[x+a,y+b,z+c,x1+d]
add (Poly[x,y,z,x1,x2])(Poly[a,b,c,d,e]) = Poly[x+a,y+b,z+c,x1+d,x2+e]
