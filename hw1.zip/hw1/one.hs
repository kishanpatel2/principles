import Data.List
median::Int -> Int -> Int -> Int 
median x y z = if maximum[x,y,z] == x && minimum[x,y,z] == z then y
    else if maximum[x,y,z] == z && minimum[x,y,z] == x then y
    else if maximum[x,y,z] == x && minimum[x,y,z] == y then z
    else if maximum[x,y,z] == y && minimum[x,y,z] == x then z
    else if maximum[x,y,z] == y && minimum[x,y,z] == z then x
    else if maximum[x,y,z] == z && minimum[x,y,z] == y then x
    else 0


