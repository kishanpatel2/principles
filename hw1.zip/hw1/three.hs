import Data.List
fibbonaci::Int->[Integer]
fibbonaci 0 = [1]
fibbonaci 1 = [1,1]
fibbonaci n = take n numbers
    where numbers = 1 : 1 : (zipWith (+) numbers (tail numbers))
          numbers < 0 = 0

