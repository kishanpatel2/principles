import Data.List
fibbonaci :: Integer -> Integer 
fibbonaci 0 = 1
fibbonaci 1 = 1
fibbonaci a = if a < 0 then 0 else (fibbonaci(a - 1) + fibbonaci(a - 2))
