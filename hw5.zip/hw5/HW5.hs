module HW5 where
data Tree a = Tip | Bin (Tree a) a (Tree a) deriving (Show, Eq)
data Rose a = Node a [Rose a] deriving (Show, Eq)

fromTree :: Tree a -> [a]
fromTree Tip = []
fromTree (Bin l x r) = fromTree l ++ [x] ++ fromTree r

--trunc :: Int -> Tree a -> Tree a
--trunc Tip = 0
--trunc (Bin l x r) = 1 + max (trunc l) (trunc r)

symmetric :: (Eq a) => Tree a -> Tree a -> Bool
symmetric (Bin left1 a1 right1) (Bin left2 a2 right2) = a1 == a2 && symmetric left1 right2 && symmetric right1 left2


sumRose :: (Num a) => Rose a -> a
sumRose (Node x cs) = x + sum (map sumRose cs)

maximumRose :: (Ord a) => Rose a -> a
maximumRose (Node x y) = maximum(x : map maximumRose y)

sizeRose :: Rose a -> Int
sizeRose (Node a []) = 1
sizeRose(Node a b) = 1 + maximum (map (sizeRose) b)

--fanout :: Rose a -> Int
--fanout (Node a []) = 0
--fanout

