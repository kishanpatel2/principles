import Data.List
import Data.Eq
data Point = Point{x::Double, y::Double, z::Double} deriving (Show, Eq)
dist (x,y) (x1,y1) =  sqrt((x-x1)^2 + (y-y1)^2)
-- Example: dist (4,5) (8,1)


