import Data.List
import Data.Eq
data Point = Point{x::Double, y::Double, z::Double} deriving (Show, Eq)
projXY (x,y,z) = (x,y,0)
