data Border = Invisible | Normal 
data Color = Red | Green | Blue
--data Width = Thin | Medium | Thick
data Line = Solid | Dashed | Dotted | Wavy
line :: Border -> Color  -> Line -> Bool
line Invisible Green Wavy  = True
line Normal Green Wavy  = True
line _      _       _= False
--Example in ghci: colorEq Invisible Green Wavy

