data Poly = Poly [Double] deriving (Show, Eq)
neg :: Poly -> Poly
neg (Poly[x]) = (Poly[x*(-1)])
neg (Poly[x,y]) = (Poly[x*(-1),y*(-1)])
neg (Poly[x,y,z]) = (Poly[x*(-1),y*(-1),z*(-1)])
neg (Poly[x,y,z,a]) = (Poly[x*(-1),y*(-1),z*(-1),a*(-1)])
neg (Poly[x,y,z,a,b]) = (Poly[x*(-1),y*(-1),z*(-1),a*(-1),b*(-1)])


 
mult :: Poly -> Poly -> Poly
mult (Poly[x,y])(Poly[a,b]) = (Poly[(x*a),(y*a + x*b),(b*y)])
mult (Poly[x])(Poly[a]) = (Poly[(x*a)])
mult (Poly[])(Poly[a,b,c]) = (Poly[])
mult (Poly[a,b,c])(Poly[]) = (Poly[])

coeffs :: [Double] -> Poly
coeffs [x] = if x == 0 then Poly[0] else Poly[0]
coeffs [x,y] = if y == 0 then Poly [x] else Poly [x,y]
coeffs [x,y,z] = if z == 0 then Poly [x,y] else Poly [x,y,z]
coeffs [x,y,z,a] = if a == 0 then Poly[x,y,z] else Poly[x,y,z,a]
coeffs [x,y,z,a,b] = if b == 0 then Poly[x,y,z,a] else Poly[x,y,z,a,b]
coeffs [x,y,z,a,b,c] = if c == 0 then Poly[x,y,z,a,b] else Poly[x,y,z,a,b,c]
coeffs [x,y,z,a,b,c,d] = if d == 0 then Poly[x,y,z,a,b,c] else Poly[x,y,z,a,b,c,d]
coeffs [x,y,z,a,b,c,d,e] = if e == 0 then Poly[x,y,z,a,b,c,d] else Poly[x,y,z,a,b,c,d,e]
coeffs [x,y,z,a,b,c,d,e,f] = if f == 0 then Poly[x,y,z,a,b,c,d,e] else Poly[x,y,z,a,b,c,d,e,f]


add:: Poly -> Poly -> Poly
add (Poly[x])(Poly[a]) = Poly[x+a]
add (Poly[x,y])(Poly[a,b]) = Poly[x+a,y+b] 
add (Poly[x,y,z])(Poly[a,b,c]) = Poly [x+a,y+b,z+c]
add (Poly[x,y,z,x1])(Poly[a,b,c,d]) = Poly[x+a,y+b,z+c,x1+d]
add (Poly[x,y,z,x1,x2])(Poly[a,b,c,d,e]) = Poly[x+a,y+b,z+c,x1+d,x2+e]

x::Poly 
instance Num Poly where
    (+) = add
    negate = neg
    (*) = mult
    fromInteger 0 = Poly []
    fromInteger n = Poly [fromInteger n]
    abs = error "No abs for Poly"
    signum = error "No signum for Poly"
j = 3
k = 1
x = Poly[j]

